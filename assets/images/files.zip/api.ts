import { Platform } from 'react-native';

/**
 * Para encontrar seu IP local:
 *  - Windows: ipconfig  (IPv4 Address)
 *  - Mac/Linux: ifconfig | grep "inet "
 *
 * Use o IP da sua máquina na rede Wi-Fi (ex: 192.168.1.5)
 * NÃO use "localhost" em dispositivos físicos — só funciona no simulador web/iOS.
 */
const DEV_IP = '192.168.1.5'; // <- TROQUE PELO SEU IP LOCAL

const DEV_URL = Platform.select({
  web: 'http://localhost:3000',        // Navegador: localhost funciona
  default: `http://${DEV_IP}:3000`,    // iOS físico / Android / Expo Go
});

export const API_URL = __DEV__
  ? DEV_URL
  : 'https://sua-api-em-producao.com'; // <- URL de produção futuramente
